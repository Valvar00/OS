#include <iostream>
#include <cstdlib>
#include <array>

using namespace std;

int seek=0;

int nearest(int *a,int hd)
{
    int nr=100000;
    int h=0;
    int i;
    for(i=0;i<8;i++){
        if(abs(a[i]-hd)<nr){
            nr=abs(a[i]-hd);
            h=a[i];
        }
    }
    seek+=nr;
    return h;
}

int SSTF(int *a,int hd){
    int del=0,ln1=8,ln2=8,k=0,seek=0,h=hd;
    for(int i=0;i<ln1;i++){
        del=nearest(a,h);
        for(int j=0;j<ln2;j++)
            if(a[j]!=del){
                a[k]=a[j];
                k++;
        }
        if(ln2==1){
            seek+=abs(a[0]-del);
            del=a[0];
        }
        else
            seek+=abs(h-del);
        k=0;
        ln2-=1;
        h=del;
    }
    return seek;
}

int SCAN(int *a,int hd,int pos,int len)
{
    int seek=0,h=hd;
    for(int i=pos;i<len;i++){
        seek+=abs(a[i]-h);
        h=a[i];
    }
    for(int i=0;i<pos;i++){
        seek+=abs(a[i]-h);
        h=a[i];
}
    return seek;
}

int FCFS(int *a,int hd)
{
    int h=hd,FCFS_seek=0;
    for(int i=0;i<8;i++){
        //cout << "\n" << a[i] << " " << h ;
        FCFS_seek+=abs(a[i]-h);
        h=a[i];
    }
    return FCFS_seek;
}


int main()
{
    int sequance[]={176,79,34,60,92,11,41,114},head=50;
    int len = sizeof(sequance)/sizeof(*sequance);
    cout << "\nFCFS algorithm seek:" << FCFS(sequance,head) << "\n";
    cout << "\nTotal SCAN seek count:" << SCAN(sequance,head,3,len) << "\n";
    cout << "\nTotal SSTF seek count:" << SSTF(sequance,head) << "\n";
    return 0;
}
