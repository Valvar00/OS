#include<bits/stdc++.h>
using namespace std;

//OPG

bool search(int key, vector<int>& fr)
{
    for (int i=0; i<fr.size();i++)
        if (fr[i]==key)
            return true;
    return false;
}

int predict(int pg[],vector<int>& fr,int pn,int index)
{
    int res=-1,farthest=index;
    for (int i=0;i<fr.size();i++) {
        int j;
        for (j=index;j<pn;j++) {
            if(fr[i]==pg[j]) {
                if(j>farthest) {
                    farthest=j;
                    res=i;
                }
                break;
            }
        }
        if (j==pn)
            return i;
    }
    return (res==-1)?0:res;
}

int optimalPage(int pg[], int pn, int fn)
{
    vector<int> fr;
    int hit=0;
    for (int i=0;i<pn;i++){
        if (search(pg[i],fr)) {
            hit++;
            continue;
        }
        if (fr.size()<fn)
            fr.push_back(pg[i]);
        else{
            int j=predict(pg,fr,pn,i+1);
            fr[j]=pg[i];
        }
    }
    return (pn-hit);
}

//LRU

int pageFaults_LRU(int pages[], int n, int capacity)
{
    int st[capacity],fail=0,ch=1,ind_ch=0,phit=0;
    for(int i=0;i<capacity;i++){
        st[i]=pages[i];
    }
    for(int i=capacity;i<n;i++){
        for(int j=0;j<capacity;j++){
            if(pages[i]==st[j]){
                ch=0;
                phit=1;
            }
        }
        if(ch==1){
            if(phit==1){
                st[ind_ch]=pages[i];
            }
            else{
            st[ind_ch]=pages[i];
            if(ind_ch==3){
                ind_ch=0;
            }
            else
            {
                ind_ch++;
            }
        }
        fail+=1;
        }
        ch=1;
    }
    return fail+capacity;
}

//FIFO

int pageFaults_FIFO(int pages[], int n, int capacity)
{
    int st[capacity+1],fail=0,ch=1,ind_ch=0;
    for(int i=0;i<capacity;i++){
        st[i]=pages[i];
    }
    for(int i=capacity;i<n;i++){
        for(int j=0;j<capacity;j++){
            if(pages[i]==st[j]){
                ch=0;
            }
        }
        if(ch==1){
            st[ind_ch]=pages[i];
            if(ind_ch==capacity-1){
                ind_ch=0;
            }
            else
            {
                ind_ch++;
            }
            fail+=1;
        }
        ch=1;
    }
    return fail+capacity;
}

int main()
{
    int pages[] = {7,0,1,2,0,3,0,4,2,3,0,3,2,1,2};
    int n = sizeof(pages)/sizeof(pages[0]);
    int capacity = 3;
    cout << "FIFO page replacement algorithm page faults:" << pageFaults_FIFO(pages, n, capacity) << "\n";
    cout << "LRU page replacement algorithm page faults:" << pageFaults_LRU(pages, n, capacity) << "\n";
    cout << "OPR page replacement algorithm page faults:" << optimalPage(pages, n, capacity) << "\n";
    return 0;
}
