#include <iostream>
#include <string>

using namespace std;



//PROJECT
class Project{
    private:
            string Name,Deadline;
    public:
        Project();
        void SetN(string N);
        void SetD(string D);
        string GetN();
        string GetD();
};

Project::Project()
{
    Name="Calculator";
    Deadline="19.01.2019";
}

void Project::SetN(string N)
{
    Name=N;
}

void Project::SetD(string D)
{
    Deadline=D;
}

string Project::GetN(){
    return Name;
}


string Project::GetD(){
    return Deadline;
}


//TEAM
class Team{
private:
    string TeamName;
public:
    Team();
    void SetTeamName(string TN);
    string GetTeamName();
};

Team::Team(){
    TeamName="VEG";
}

string Team::GetTeamName(){
    return TeamName;
}

void Team::SetTeamName(string TN)
{
    TeamName=TN;
}

//PERSON
class Person : public Team
{
private:
    string PersonName;
public:
    Person();
    void SetPersonName(string PN);
    string GetPersonName();
};

Person::Person(){
    PersonName="John";
}

void Person::SetPersonName(string PN)
{
    PersonName=PN;
}

string Person::GetPersonName(){
    return PersonName;
}


//TEAMLEDER
class Teamleader : public Person {
private:
    int Rank;
public:
    Teamleader();
    void SetRank(int R);
    int GetRank();
};

Teamleader::Teamleader(){
    Rank=1;
}

void Teamleader::SetRank(int R)
{
    Rank=R;
}

int Teamleader::GetRank(){
    return Rank;
}


//ITERATION
class Iteration{
private:
    string IName;
    string IDeadline;
public:
    Iteration();
    void SetIName(string IN);
    void SetIDeadline(string ID);
    string GetIName();
    string GetIDeadline();
};

Iteration::Iteration(){
    IName="It";
    IDeadline="19.01.2019";
}

void Iteration::SetIName(string IN)
{
    IName=IN;
}

void Iteration::SetIDeadline(string ID)
{
    IDeadline=ID;
}

string Iteration::GetIDeadline(){
    return IDeadline;
}

string Iteration::GetIName(){
    return IName;
}

//TAST

class Task{
private:
    string Title;
    string Content;
    int Number_of_planned_hours;
    int Number_of_real_hours;
    bool State;
public:
    Task();
    void SetTitle(string T);
    void SetContent(string C);
    void SetPHours(int P);
    void SetRHours(int R);
    void SetState(bool S);
    string GetTitle();
    string GetContent();
    int GetPHours();
    int GetRHours();
    bool GetState();
};

Task::Task(){
    Title="Multi";
    Content="Multiply 2 numbers";
    Number_of_planned_hours=3;
    Number_of_real_hours=2;
    State=true;
}

string Task::GetTitle(){
    return Title;
}

string Task::GetContent(){
    return Content;
}

int Task::GetPHours(){
    return Number_of_planned_hours;
}

int Task::GetRHours(){
    return Number_of_real_hours;
}

bool Task::GetState(){
    return State;
}

void Task::SetTitle(string T)
{
    Title=T;
}

void Task::SetContent(string C)
{
    Content=C;
}

void Task::SetPHours(int P)
{
    Number_of_planned_hours=P;
}

void Task::SetRHours(int R)
{
    Number_of_real_hours=R;
}
void Task::SetState(bool S)
{
    State=S;
}

//OWNER
class Owner{
private:
    string OName;
public:
    Owner();
    void SetOName(string ON);
    string GetOName();
};

Owner::Owner(){
    OName="Peter";
}

void Owner::SetOName(string ON){
    OName=ON;
}

string Owner::GetOName(){
return OName;
}

int main()
{
    Project pr1;
    Team t1;
    Person p1;
    Teamleader PT1;
    Iteration I1;
    Task T1;
    Owner O1;
    cout << "Project:" << pr1.GetN() << " Project Deadline:" << pr1.GetD() << "\n";
    cout << "TEAM:" << t1.GetTeamName() << "\n" ;
    cout << "Person:" << p1.GetPersonName() << "\n";
    cout << "TL:" << PT1.GetPersonName() << " TL rank:" << PT1.GetRank() << "\n";
    cout << "Iteration:" << I1.GetIName()<< " Iteration Deadline:" << I1.GetIDeadline() << "\n";
    cout << "Task:" << T1.GetTitle()<< " Content:" << T1.GetContent()<< " Planned hours:" << T1.GetPHours()<< " Real Hours:" << T1.GetRHours() << " State:" << T1.GetState()<< "\n";
    cout << "Owner:" << O1.GetOName() << "\n";
}
