#include <iostream>
# include <stdio.h>
# include <math.h>
using namespace std;
/* Первое задание
using namespace std;

int main()
{
    int arr[]={0,1,0},n=0,val=0;
    cin >> n ;
    for(int i=0;i<n-2;i++){
        val=arr[1];
        arr[2]=arr[1]+arr[0];
        arr[1]=arr[2];
        arr[0]=val;
    }
    cout << arr[2] ;
}
*/

/* Второе задание
using namespace std;

int main(){
    int check=1,n=0,ch2=1;
    cin >> n ;
    if(n%2==0){
        ch2=0;
        check=0;
        }
    if(ch2==1)
        for(int i=3;i<n-1;i+=2)
            if(n%i==0){
                check=0;
                break;
        }
    if(check==1)
        cout << "Prime number!" ;
    else
        cout << "Not Prime Number!" ;
}
*/

/* Third exercise
void primeFactors(int n)
{
    while (n%2==0)
    {
        cout <<  2 << ' ';
        n = n/2;
    }
    for (int i=3;i<=sqrt(n);i+=2)
    {
        while (n%i==0)
        {
            cout << i << ' ';
            n = n/i;
        }
    }
    if (n>2)
        cout << n;
}

int main()
{
    int n=0;
    cin >> n ;
    primeFactors(n);
    return 0;
}
*/
